package ie.gmit.sw;
public class Runner {
	/**
	 * This class starts the main application
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		new Menu().displayMenu();
	}
}
