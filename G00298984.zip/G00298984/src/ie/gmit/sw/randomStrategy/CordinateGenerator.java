package ie.gmit.sw.randomStrategy;

public interface CordinateGenerator {

	public abstract int getX(int max);

	public abstract int getY(int max);
}
