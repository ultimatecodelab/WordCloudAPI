package ie.gmit.sw.parser;

public enum ParseType {
	FileParser, URLParse
}
